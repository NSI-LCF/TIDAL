
<?php
/* 42.505636,1.515349
6215b21fb6ed42d8980160421210212
*/
$meteo_xml=new SimpleXMLElement(file_get_contents("https://api.weatherapi.com/v1/current.xml?key=6215b21fb6ed42d8980160421210212&q=42.505636,1.515349&aqi=no"));
print("<pre>");
var_dump($meteo_xml);
print("</pre>");
?>
